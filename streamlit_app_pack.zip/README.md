# App Streamlit – DTR con feedback
Ver instrucciones dentro de app.py y README.